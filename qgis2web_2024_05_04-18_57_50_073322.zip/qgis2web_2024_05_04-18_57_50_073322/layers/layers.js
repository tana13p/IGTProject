var wms_layers = [];


        var lyr_OSMStandard_0 = new ol.layer.Tile({
            'title': 'OSM Standard',
            //'type': 'base',
            'opacity': 1.000000,
            
            
            source: new ol.source.XYZ({
    attributions: ' &middot; <a href="https://www.openstreetmap.org/copyright">© OpenStreetMap contributors, CC-BY-SA</a>',
                url: 'http://tile.openstreetmap.org/{z}/{x}/{y}.png'
            })
        });
var format_India_State_Boundary_1 = new ol.format.GeoJSON();
var features_India_State_Boundary_1 = format_India_State_Boundary_1.readFeatures(json_India_State_Boundary_1, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_India_State_Boundary_1 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_India_State_Boundary_1.addFeatures(features_India_State_Boundary_1);
var lyr_India_State_Boundary_1 = new ol.layer.Vector({
                declutter: false,
                source:jsonSource_India_State_Boundary_1, 
                style: style_India_State_Boundary_1,
                popuplayertitle: "India_State_Boundary",
                interactive: true,
    title: 'India_State_Boundary<br />\
    <img src="styles/legend/India_State_Boundary_1_0.png" /> Maharashtra<br />'
        });
var format_amenity_library_maharashtra_2 = new ol.format.GeoJSON();
var features_amenity_library_maharashtra_2 = format_amenity_library_maharashtra_2.readFeatures(json_amenity_library_maharashtra_2, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_amenity_library_maharashtra_2 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_amenity_library_maharashtra_2.addFeatures(features_amenity_library_maharashtra_2);
var lyr_amenity_library_maharashtra_2 = new ol.layer.Vector({
                declutter: false,
                source:jsonSource_amenity_library_maharashtra_2, 
                style: style_amenity_library_maharashtra_2,
                popuplayertitle: "amenity_library_maharashtra",
                interactive: true,
                title: '<img src="styles/legend/amenity_library_maharashtra_2.png" /> amenity_library_maharashtra'
            });
var format_Igt_LIBSheet16_3 = new ol.format.GeoJSON();
var features_Igt_LIBSheet16_3 = format_Igt_LIBSheet16_3.readFeatures(json_Igt_LIBSheet16_3, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_Igt_LIBSheet16_3 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_Igt_LIBSheet16_3.addFeatures(features_Igt_LIBSheet16_3);
var lyr_Igt_LIBSheet16_3 = new ol.layer.Vector({
                declutter: false,
                source:jsonSource_Igt_LIBSheet16_3, 
                style: style_Igt_LIBSheet16_3,
                popuplayertitle: "Igt_LIB - Sheet1 (6)",
                interactive: true,
                title: '<img src="styles/legend/Igt_LIBSheet16_3.png" /> Igt_LIB - Sheet1 (6)'
            });
var format_PublicLibraries_4 = new ol.format.GeoJSON();
var features_PublicLibraries_4 = format_PublicLibraries_4.readFeatures(json_PublicLibraries_4, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_PublicLibraries_4 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_PublicLibraries_4.addFeatures(features_PublicLibraries_4);
var lyr_PublicLibraries_4 = new ol.layer.Vector({
                declutter: false,
                source:jsonSource_PublicLibraries_4, 
                style: style_PublicLibraries_4,
                popuplayertitle: "PublicLibraries",
                interactive: true,
                title: '<img src="styles/legend/PublicLibraries_4.png" /> PublicLibraries'
            });

lyr_OSMStandard_0.setVisible(true);lyr_India_State_Boundary_1.setVisible(true);lyr_amenity_library_maharashtra_2.setVisible(true);lyr_Igt_LIBSheet16_3.setVisible(true);lyr_PublicLibraries_4.setVisible(true);
var layersList = [lyr_OSMStandard_0,lyr_India_State_Boundary_1,lyr_amenity_library_maharashtra_2,lyr_Igt_LIBSheet16_3,lyr_PublicLibraries_4];
lyr_India_State_Boundary_1.set('fieldAliases', {'Name': 'Name', 'Type': 'Type', });
lyr_amenity_library_maharashtra_2.set('fieldAliases', {'fid': 'fid', 'full_id': 'full_id', 'osm_id': 'osm_id', 'osm_type': 'osm_type', 'amenity': 'amenity', 'mobile': 'mobile', 'contact:instagram': 'contact:instagram', 'contact:facebook': 'contact:facebook', 'name:hi': 'name:hi', 'website': 'website', 'level': 'level', 'payment:credit_cards': 'payment:credit_cards', 'payment:cash': 'payment:cash', 'air_conditioning': 'air_conditioning', 'religion': 'religion', 'phone': 'phone', 'grades': 'grades', 'addr:district': 'addr:district', 'operator:type': 'operator:type', 'internet_access:ssid': 'internet_access:ssid', 'internet_access:fee': 'internet_access:fee', 'opening_hours': 'opening_hours', 'wikipedia': 'wikipedia', 'wikimedia_commons': 'wikimedia_commons', 'wikidata': 'wikidata', 'designation': 'designation', 'internet_access': 'internet_access', 'name:mr': 'name:mr', 'operator': 'operator', 'name:etymology:wikidata': 'name:etymology:wikidata', 'addr:street': 'addr:street', 'addr:postcode': 'addr:postcode', 'addr:housenumber': 'addr:housenumber', 'addr:city': 'addr:city', 'check_date': 'check_date', 'addr:full': 'addr:full', 'name:en': 'name:en', 'name': 'name', });
lyr_Igt_LIBSheet16_3.set('fieldAliases', {'Sr no': 'Sr no', 'Name of library': 'Name of library', 'x coord': 'x coord', 'y coord': 'y coord', 'Addresss': 'Addresss', });
lyr_PublicLibraries_4.set('fieldAliases', {'Name': 'Name', 'description': 'description', 'timestamp': 'timestamp', 'begin': 'begin', 'end': 'end', 'altitudeMode': 'altitudeMode', 'tessellate': 'tessellate', 'extrude': 'extrude', 'visibility': 'visibility', 'drawOrder': 'drawOrder', 'icon': 'icon', });
lyr_India_State_Boundary_1.set('fieldImages', {'Name': 'TextEdit', 'Type': 'TextEdit', });
lyr_amenity_library_maharashtra_2.set('fieldImages', {'fid': '', 'full_id': 'TextEdit', 'osm_id': 'TextEdit', 'osm_type': 'TextEdit', 'amenity': 'TextEdit', 'mobile': 'TextEdit', 'contact:instagram': 'TextEdit', 'contact:facebook': 'TextEdit', 'name:hi': 'TextEdit', 'website': 'TextEdit', 'level': 'TextEdit', 'payment:credit_cards': 'TextEdit', 'payment:cash': 'TextEdit', 'air_conditioning': 'TextEdit', 'religion': 'TextEdit', 'phone': 'TextEdit', 'grades': 'TextEdit', 'addr:district': 'TextEdit', 'operator:type': 'TextEdit', 'internet_access:ssid': 'TextEdit', 'internet_access:fee': 'TextEdit', 'opening_hours': 'TextEdit', 'wikipedia': 'TextEdit', 'wikimedia_commons': 'TextEdit', 'wikidata': 'TextEdit', 'designation': 'TextEdit', 'internet_access': 'TextEdit', 'name:mr': 'TextEdit', 'operator': 'TextEdit', 'name:etymology:wikidata': 'TextEdit', 'addr:street': 'TextEdit', 'addr:postcode': 'TextEdit', 'addr:housenumber': 'TextEdit', 'addr:city': 'TextEdit', 'check_date': 'TextEdit', 'addr:full': 'TextEdit', 'name:en': 'TextEdit', 'name': 'TextEdit', });
lyr_Igt_LIBSheet16_3.set('fieldImages', {'Sr no': 'TextEdit', 'Name of library': 'TextEdit', 'x coord': 'TextEdit', 'y coord': 'TextEdit', 'Addresss': 'TextEdit', });
lyr_PublicLibraries_4.set('fieldImages', {'Name': 'TextEdit', 'description': 'TextEdit', 'timestamp': 'DateTime', 'begin': 'DateTime', 'end': 'DateTime', 'altitudeMode': 'TextEdit', 'tessellate': 'Range', 'extrude': 'Range', 'visibility': 'Range', 'drawOrder': 'Range', 'icon': 'TextEdit', });
lyr_India_State_Boundary_1.set('fieldLabels', {'Name': 'no label', 'Type': 'no label', });
lyr_amenity_library_maharashtra_2.set('fieldLabels', {'fid': 'no label', 'full_id': 'no label', 'osm_id': 'no label', 'osm_type': 'no label', 'amenity': 'no label', 'mobile': 'no label', 'contact:instagram': 'no label', 'contact:facebook': 'no label', 'name:hi': 'no label', 'website': 'no label', 'level': 'no label', 'payment:credit_cards': 'no label', 'payment:cash': 'no label', 'air_conditioning': 'no label', 'religion': 'no label', 'phone': 'no label', 'grades': 'no label', 'addr:district': 'no label', 'operator:type': 'no label', 'internet_access:ssid': 'no label', 'internet_access:fee': 'no label', 'opening_hours': 'no label', 'wikipedia': 'no label', 'wikimedia_commons': 'no label', 'wikidata': 'no label', 'designation': 'no label', 'internet_access': 'no label', 'name:mr': 'no label', 'operator': 'no label', 'name:etymology:wikidata': 'no label', 'addr:street': 'no label', 'addr:postcode': 'no label', 'addr:housenumber': 'no label', 'addr:city': 'no label', 'check_date': 'no label', 'addr:full': 'no label', 'name:en': 'no label', 'name': 'no label', });
lyr_Igt_LIBSheet16_3.set('fieldLabels', {'Sr no': 'no label', 'Name of library': 'no label', 'x coord': 'no label', 'y coord': 'no label', 'Addresss': 'no label', });
lyr_PublicLibraries_4.set('fieldLabels', {'Name': 'no label', 'description': 'no label', 'timestamp': 'no label', 'begin': 'no label', 'end': 'no label', 'altitudeMode': 'header label - visible with data', 'tessellate': 'no label', 'extrude': 'no label', 'visibility': 'no label', 'drawOrder': 'no label', 'icon': 'no label', });
lyr_PublicLibraries_4.on('precompose', function(evt) {
    evt.context.globalCompositeOperation = 'normal';
});